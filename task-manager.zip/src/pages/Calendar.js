import CalendarView from '../components/CalendarView';

function Calendar() {
  return (
    <div>
      <h2>Calendar View</h2>
      <CalendarView />
    </div>
  );
}
export default Calendar;
